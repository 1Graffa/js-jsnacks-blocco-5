// Creare un oggetto palla che abbia le seguenti proprietà.
// Nome = palla
// Peso = 10
// Attraverso un prompt dare la possibilità all'utente di modificare il peso della palla.

var palla= {
    nome: 'palla',
    peso: 10
};

var pesoP = parseInt(prompt('Inserire il nuovo peso della palla'));

palla.peso = pesoP;
console.log(palla);
for( var k in palla){
    console.log(k + ': ' +palla[k]);
}