/* 
Creare  un array che contiene 10 oggetti che rappresentano una zucchina.
Dividi in due array separati le zucchine che misurano meno o più di 15cm. 
Infine stampa separatamente quanto pesano i due gruppi di zucchine.
*/

var zucchina = [
    {
        'varieta' : 'corta',
        'peso' : 10,
        'lunghezza' : 12
    },
    {
        'varieta' : 'lunga',
        'peso' : 11,
        'lunghezza' : 16
    },
    {
        'varieta' : 'media',
        'peso' : 12,
        'lunghezza' : 17
    },
    {
        'varieta' : 'corta',
        'peso' : 13,
        'lunghezza' : 13
    },
    {
        'varieta' : 'lunga',
        'peso' : 14,
        'lunghezza' : 14
    },
    {
        'varieta' : 'media',
        'peso' : 10,
        'lunghezza' : 15
    },
    {
        'varieta' : 'corta',
        'peso' : 10,
        'lunghezza' : 18
    },
    {
        'varieta' : 'lunga',
        'peso' : 10,
        'lunghezza' : 19
    },
    {
        'varieta' : 'media',
        'peso' : 10,
        'lunghezza' : 11
    },
    {
        'varieta' : 'corta',
        'peso' : 10,
        'lunghezza' : 10
    }
];

var arrayMinore = [];
var arrayMaggiore = [];

var sommaMinore = 0;
var sommaMaggiore = 0;

//Soluzione con somma all'interno di un unico ciclo for
for(var i = 0; i < zucchina.length; i++){
    if(zucchina[i].lunghezza < 15){
        arrayMinore.push(zucchina[i]);
        sommaMinore += zucchina[i].peso;
    } else {
        arrayMaggiore.push(zucchina[i]);
        sommaMaggiore += zucchina[i].peso;
    }
}

console.log(arrayMinore);
console.log(arrayMaggiore);

//Soluzione con cicli for esterni
/* for(var i = 0; i < arrayMinore.length; i++){
    sommaMinore += arrayMinore[i].peso;
}

for(var i = 0; i < arrayMaggiore.length; i++){
    sommaMaggiore += arrayMaggiore[i].peso;
} */

console.log('La somma del peso delle zucchine con lunghezza minore di 15 cm è: ' + sommaMinore);
console.log('La somma del peso delle zucchine con lunghezza maggiore di 15 cm è: ' + sommaMaggiore);